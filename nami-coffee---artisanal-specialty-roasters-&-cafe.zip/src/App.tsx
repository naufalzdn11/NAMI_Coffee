import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { MenuSection } from './components/MenuSection';
import { BrewCalculator } from './components/BrewCalculator';
import { StorySection } from './components/StorySection';
import { LocationsAndReservation } from './components/LocationsAndReservation';
import { ReviewsSection } from './components/ReviewsSection';
import { Footer } from './components/Footer';
import { ProductCustomizerModal } from './components/ProductCustomizerModal';
import { CartDrawer } from './components/CartDrawer';
import { OrderReceiptModal } from './components/OrderReceiptModal';
import { Product, CartItem, PRODUCTS } from './data/coffeeData';
import { ShoppingBag } from 'lucide-react';

export default function App() {
  const [cartItems, setCartItems] = useState<CartItem[]>([
    // Provide 1 starter item so the cart isn't completely empty on demo
    {
      cartItemId: 'starter-1',
      product: PRODUCTS[0], // Nami Cloud Sea Salt Latte
      quantity: 1,
      temperature: 'Iced',
      sweetness: 'Normal (100%)',
      milk: 'Fresh Milk',
      unitPrice: 38000
    }
  ]);

  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [activeReceiptOrder, setActiveReceiptOrder] = useState<any | null>(null);

  // Cart actions
  const handleAddToCart = (item: CartItem) => {
    setCartItems((prev) => {
      // Check if identical item configuration exists
      const existingIdx = prev.findIndex(
        (i) =>
          i.product.id === item.product.id &&
          i.temperature === item.temperature &&
          i.sweetness === item.sweetness &&
          i.milk === item.milk &&
          i.grindSize === item.grindSize &&
          i.notes === item.notes
      );

      if (existingIdx > -1) {
        const updated = [...prev];
        updated[existingIdx].quantity += item.quantity;
        return updated;
      }
      return [...prev, item];
    });
  };

  const handleQuickAdd = (product: Product) => {
    const isDrink = product.category === 'signature' || product.category === 'espresso' || product.category === 'manual';
    const isBean = product.category === 'beans';

    const newItem: CartItem = {
      cartItemId: `${product.id}-${Date.now()}`,
      product,
      quantity: 1,
      temperature: isDrink ? 'Iced' : undefined,
      sweetness: isDrink && product.category !== 'manual' ? 'Normal (100%)' : undefined,
      milk: isDrink && product.category !== 'manual' ? 'Fresh Milk' : undefined,
      grindSize: isBean ? 'Whole Bean (Biji Utuh)' : undefined,
      unitPrice: product.price
    };

    handleAddToCart(newItem);
    setIsCartOpen(true);
  };

  const handleUpdateQuantity = (cartItemId: string, newQty: number) => {
    if (newQty <= 0) {
      handleRemoveItem(cartItemId);
      return;
    }
    setCartItems((prev) =>
      prev.map((i) => (i.cartItemId === cartItemId ? { ...i, quantity: newQty } : i))
    );
  };

  const handleRemoveItem = (cartItemId: string) => {
    setCartItems((prev) => prev.filter((i) => i.cartItemId !== cartItemId));
  };

  const handleProceedToReceipt = (orderDetails: any) => {
    setActiveReceiptOrder(orderDetails);
    setCartItems([]);
    setIsCartOpen(false);
  };

  const totalCartCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#FAF8F5] text-[#1C1917] flex flex-col font-sans selection:bg-[#B45309]/20 selection:text-[#78350F]">
      
      {/* Strict 3-zone Header */}
      <Navbar
        cartCount={totalCartCount}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenReservation={() => scrollToSection('lokasi')}
      />

      {/* Main Experience Flow */}
      <main className="flex-1">
        {/* Campaign Hero with high-fidelity asset */}
        <HeroSection
          onExploreMenu={() => scrollToSection('menu')}
          onOpenBrewGuide={() => scrollToSection('brew-guide')}
        />

        {/* Product Catalog & Curated Offerings */}
        <MenuSection
          onSelectProduct={(prod) => setSelectedProduct(prod)}
          onQuickAdd={handleQuickAdd}
        />

        {/* Interactive Barista Brew Tool with Live Stopwatch */}
        <BrewCalculator />

        {/* Story, Roastery Craft, and 48-Hour French Viennoiserie */}
        <StorySection />

        {/* Sanctuaries & Table Reservation Module */}
        <LocationsAndReservation />

        {/* Verified Community & Critic Reviews */}
        <ReviewsSection />
      </main>

      {/* Clean Editorial Footer */}
      <Footer />

      {/* Product Customizer Modal */}
      {selectedProduct && (
        <ProductCustomizerModal
          product={selectedProduct}
          onClose={() => setSelectedProduct(null)}
          onAddToCart={handleAddToCart}
        />
      )}

      {/* Slide-out Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onProceedToReceipt={handleProceedToReceipt}
      />

      {/* Order Confirmed Receipt Modal */}
      {activeReceiptOrder && (
        <OrderReceiptModal
          order={activeReceiptOrder}
          onClose={() => setActiveReceiptOrder(null)}
        />
      )}

      {/* Mobile Floating Cart Access Bar (Strictly capped $\le 15\%$ viewport height) */}
      {totalCartCount > 0 && !isCartOpen && (
        <div className="fixed bottom-4 inset-x-4 z-30 sm:hidden">
          <button
            onClick={() => setIsCartOpen(true)}
            className="w-full py-3 px-4 bg-[#1C1917] text-white rounded-xl shadow-xl flex items-center justify-between font-semibold text-xs active:scale-98 transition-transform"
          >
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-4 h-4 text-amber-300" />
              <span>{totalCartCount} Item di Pesanan</span>
            </div>
            <span className="font-mono tabular-nums text-amber-200">
              Lihat Keranjang →
            </span>
          </button>
        </div>
      )}

    </div>
  );
}
