import React, { useState } from 'react';
import { X, Plus, Minus, Trash2, ShoppingBag, ArrowRight, Check } from 'lucide-react';
import { CartItem } from '../data/coffeeData';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (cartItemId: string, newQty: number) => void;
  onRemoveItem: (cartItemId: string) => void;
  onProceedToReceipt: (orderDetails: {
    orderId: string;
    customerName: string;
    customerPhone: string;
    orderType: 'Dine-In' | 'Takeaway' | 'Delivery';
    tableOrAddress: string;
    items: CartItem[];
    subtotal: number;
    tax: number;
    total: number;
  }) => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onProceedToReceipt
}) => {
  const [orderType, setOrderType] = useState<'Dine-In' | 'Takeaway' | 'Delivery'>('Dine-In');
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [tableOrAddress, setTableOrAddress] = useState('Meja 04');

  if (!isOpen) return null;

  const subtotal = items.reduce((sum, item) => sum + item.unitPrice * item.quantity, 0);
  const tax = Math.round(subtotal * 0.1); // PB1 10%
  const total = subtotal + tax;

  const handleCheckout = (e: React.FormEvent) => {
    e.preventDefault();
    if (items.length === 0) return;
    if (!customerName.trim() || !customerPhone.trim()) {
      alert('Mohon isi nama dan nomor WhatsApp untuk memproses pesanan.');
      return;
    }

    const orderId = `NAMI-${Math.floor(1000 + Math.random() * 9000)}`;
    onProceedToReceipt({
      orderId,
      customerName: customerName.trim(),
      customerPhone: customerPhone.trim(),
      orderType,
      tableOrAddress: tableOrAddress.trim(),
      items,
      subtotal,
      tax,
      total
    });
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/60 backdrop-blur-xs flex justify-end">
      <div 
        className="w-full max-w-md bg-[#FAF8F5] h-full shadow-2xl flex flex-col border-l border-[#E0D7CB] animate-in slide-in-from-right duration-300"
        role="dialog"
        aria-modal="true"
        aria-labelledby="cart-title"
      >
        {/* Drawer Header */}
        <div className="px-6 py-5 border-b border-[#E8E1D9] flex items-center justify-between bg-white shrink-0">
          <div className="flex items-center gap-2.5">
            <ShoppingBag className="w-5 h-5 text-[#B45309]" />
            <h2 id="cart-title" className="font-serif text-lg font-bold text-[#1C1917]">
              Pesanan Anda ({items.reduce((acc, i) => acc + i.quantity, 0)})
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#78716C] hover:text-[#1C1917] hover:bg-[#F2ECE4] rounded-md transition-colors"
            aria-label="Tutup keranjang"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Cart Item List */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {items.length === 0 ? (
            <div className="text-center py-20 space-y-3">
              <div className="w-16 h-16 bg-[#F2ECE4] rounded-full flex items-center justify-center mx-auto text-[#78716C]">
                <ShoppingBag className="w-8 h-8" />
              </div>
              <h3 className="font-serif text-lg font-bold text-[#1C1917]">
                Keranjang Masih Kosong
              </h3>
              <p className="text-xs text-[#78716C] max-w-xs mx-auto">
                Eksplor menu signature coffee dan fresh pastries kami untuk memulai pesanan.
              </p>
              <button
                type="button"
                onClick={onClose}
                className="mt-2 px-5 py-2 text-xs font-semibold bg-[#1C1917] text-white rounded-md hover:bg-[#2E2A27]"
              >
                Kembali ke Menu
              </button>
            </div>
          ) : (
            <div className="space-y-3.5">
              {items.map((item) => (
                <div
                  key={item.cartItemId}
                  className="p-3.5 bg-white rounded-xl border border-[#E8E1D9] shadow-2xs flex gap-3 items-start"
                >
                  <img
                    src={item.product.image}
                    alt={item.product.name}
                    className="w-16 h-16 object-cover rounded-lg bg-[#EAE0D3] shrink-0"
                    referrerPolicy="no-referrer"
                  />

                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <h4 className="text-xs font-bold text-[#1C1917] leading-tight truncate">
                        {item.product.name}
                      </h4>
                      <button
                        onClick={() => onRemoveItem(item.cartItemId)}
                        className="text-[#A8A29E] hover:text-red-600 transition-colors p-0.5"
                        aria-label="Hapus item"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    {/* Modifiers info */}
                    <div className="text-[11px] text-[#78716C] mt-1 space-y-0.5">
                      {item.temperature && <div>Suhu: {item.temperature}</div>}
                      {item.sweetness && <div>Gula: {item.sweetness}</div>}
                      {item.milk && <div>Susu: {item.milk}</div>}
                      {item.grindSize && <div>Giling: {item.grindSize}</div>}
                      {item.notes && <div className="italic text-[#8C6D53]">"{item.notes}"</div>}
                    </div>

                    {/* Price and Quantity Stepper */}
                    <div className="mt-2.5 flex items-center justify-between">
                      <span className="font-mono text-xs font-bold text-[#1C1917] tabular-nums">
                        Rp {(item.unitPrice * item.quantity).toLocaleString('id-ID')}
                      </span>

                      <div className="flex items-center border border-[#DDD3C7] rounded-md bg-[#FAF8F5]">
                        <button
                          type="button"
                          onClick={() => onUpdateQuantity(item.cartItemId, item.quantity - 1)}
                          className="px-2 py-0.5 text-xs text-[#57534E] hover:bg-[#EAE0D3]"
                        >
                          -
                        </button>
                        <span className="px-2 text-[11px] font-mono font-bold">{item.quantity}</span>
                        <button
                          type="button"
                          onClick={() => onUpdateQuantity(item.cartItemId, item.quantity + 1)}
                          className="px-2 py-0.5 text-xs text-[#57534E] hover:bg-[#EAE0D3]"
                        >
                          +
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Customer details & fulfillment section (only if items > 0) */}
          {items.length > 0 && (
            <div className="pt-4 border-t border-[#E8E1D9] space-y-4 text-xs">
              <div>
                <label className="block text-[#1C1917] font-bold uppercase tracking-wider mb-2">
                  Metode Pesanan
                </label>
                <div className="grid grid-cols-3 gap-1.5 p-1 bg-[#EAE2D7] rounded-lg">
                  {(['Dine-In', 'Takeaway', 'Delivery'] as const).map((type) => (
                    <button
                      key={type}
                      type="button"
                      onClick={() => setOrderType(type)}
                      className={`py-1.5 text-[11px] font-semibold rounded-md transition-all ${
                        orderType === type
                          ? 'bg-white text-[#1C1917] shadow-xs'
                          : 'text-[#57534E] hover:text-[#1C1917]'
                      }`}
                    >
                      {type}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-[#1C1917] font-bold uppercase tracking-wider mb-1">
                  {orderType === 'Dine-In' ? 'Nomor Meja' : orderType === 'Takeaway' ? 'Waktu Pengambilan' : 'Alamat Pengantaran'}
                </label>
                <input
                  type="text"
                  value={tableOrAddress}
                  onChange={(e) => setTableOrAddress(e.target.value)}
                  placeholder={
                    orderType === 'Dine-In'
                      ? 'Contoh: Meja 05 (Lantai 1)'
                      : orderType === 'Takeaway'
                      ? 'Contoh: Ambil dalam 15 menit'
                      : 'Contoh: Jl. Senopati No. 12'
                  }
                  className="w-full px-3 py-2 bg-white border border-[#DDD3C7] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#8C6D53]"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[#1C1917] font-bold uppercase tracking-wider mb-1">
                    Nama Pemesan
                  </label>
                  <input
                    type="text"
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="Nama Anda"
                    className="w-full px-3 py-2 bg-white border border-[#DDD3C7] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#8C6D53]"
                  />
                </div>

                <div>
                  <label className="block text-[#1C1917] font-bold uppercase tracking-wider mb-1">
                    No. WhatsApp
                  </label>
                  <input
                    type="tel"
                    required
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    placeholder="0812xxxx"
                    className="w-full px-3 py-2 bg-white border border-[#DDD3C7] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#8C6D53]"
                  />
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Drawer Footer with Price Breakdown */}
        {items.length > 0 && (
          <div className="p-5 border-t border-[#E8E1D9] bg-[#F7F3EE] space-y-3 shrink-0">
            <div className="space-y-1.5 text-xs text-[#57534E]">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span className="font-mono tabular-nums">Rp {subtotal.toLocaleString('id-ID')}</span>
              </div>
              <div className="flex justify-between">
                <span>Pajak Restoran (PB1 10%)</span>
                <span className="font-mono tabular-nums">Rp {tax.toLocaleString('id-ID')}</span>
              </div>
              <div className="flex justify-between text-sm font-bold text-[#1C1917] pt-2 border-t border-[#E0D7CB]">
                <span>Total Pembayaran</span>
                <span className="font-mono tabular-nums text-base text-[#B45309]">
                  Rp {total.toLocaleString('id-ID')}
                </span>
              </div>
            </div>

            <button
              type="button"
              onClick={handleCheckout}
              className="w-full py-3.5 px-4 rounded-lg text-xs sm:text-sm font-semibold text-white bg-[#1C1917] hover:bg-[#2E2A27] transition-all shadow-sm active:scale-98 flex items-center justify-center gap-2"
            >
              <span>Kirim Pesanan ke Barista</span>
              <ArrowRight className="w-4 h-4 text-amber-200" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
