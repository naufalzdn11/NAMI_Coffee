import React from 'react';
import { Star, Quote } from 'lucide-react';
import { REVIEWS } from '../data/coffeeData';

export const ReviewsSection: React.FC = () => {
  return (
    <section className="py-16 sm:py-20 border-t border-[#E8E1D9] bg-[#FAF8F5]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-[#8C6D53] tracking-widest uppercase mb-2">
              <span>Ulasan & Apresiasi</span>
              <span aria-hidden="true">·</span>
              <span>Komunitas Pecinta Kopi</span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl text-[#1C1917] font-bold tracking-tight">
              Kesan Pengunjung NAMI
            </h2>
          </div>

          <div className="flex items-center gap-3 text-xs text-[#78716C] font-mono">
            <span className="font-bold text-[#1C1917] text-base">4.9 / 5.0</span>
            <span>(2.400+ Ulasan Google & Manual Brew Enthusiasts)</span>
          </div>
        </div>

        {/* 3-Column Reviews Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
          {REVIEWS.map((rev) => (
            <div
              key={rev.id}
              className="p-6 sm:p-7 rounded-2xl bg-white border border-[#E8E1D9] flex flex-col justify-between shadow-2xs hover:border-[#D6CCC2] transition-colors"
            >
              <div className="space-y-3.5">
                {/* Star rating */}
                <div className="flex items-center gap-1 text-amber-500">
                  {Array.from({ length: rev.rating }).map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-amber-500 text-amber-500" />
                  ))}
                </div>

                {/* Review Text */}
                <p className="text-xs sm:text-sm text-[#44403C] leading-relaxed">
                  "{rev.comment}"
                </p>
              </div>

              <div className="pt-5 mt-4 border-t border-[#F2ECE4] flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold text-[#1C1917]">{rev.author}</h4>
                  <p className="text-[11px] text-[#78716C]">{rev.role}</p>
                </div>

                <div className="text-right">
                  <span className="text-[10px] font-mono text-[#8C6D53] bg-[#FAF6F0] px-2 py-0.5 rounded border border-[#EAE2D7]">
                    {rev.favorite}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
