import React, { useState, useMemo } from 'react';
import { Search, Plus, Coffee, Sparkles } from 'lucide-react';
import { Product, PRODUCTS } from '../data/coffeeData';

interface MenuSectionProps {
  onSelectProduct: (product: Product) => void;
  onQuickAdd: (product: Product) => void;
}

type CategoryType = 'all' | 'signature' | 'manual' | 'espresso' | 'bakery' | 'beans';

export const MenuSection: React.FC<MenuSectionProps> = ({
  onSelectProduct,
  onQuickAdd
}) => {
  const [activeCategory, setActiveCategory] = useState<CategoryType>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const categories = [
    { id: 'all', label: 'Semua Menu' },
    { id: 'signature', label: 'Signature Drink' },
    { id: 'manual', label: 'Manual Brew (V60)' },
    { id: 'espresso', label: 'Espresso Bar' },
    { id: 'bakery', label: 'Fresh Bakery' },
    { id: 'beans', label: 'Biji Kopi (250g)' },
  ];

  const filteredProducts = useMemo(() => {
    return PRODUCTS.filter((item) => {
      const matchCategory =
        activeCategory === 'all' || item.category === activeCategory;
      const matchSearch =
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.notes.some((n) => n.toLowerCase().includes(searchQuery.toLowerCase()));
      return matchCategory && matchSearch;
    });
  }, [activeCategory, searchQuery]);

  return (
    <section id="menu" className="py-16 sm:py-20 border-t border-[#E8E1D9]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-[#8C6D53] tracking-widest uppercase mb-2">
              <span>Kurasi Menu Harian</span>
              <span aria-hidden="true">·</span>
              <span>Bahan Pilihan Terbaik</span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl text-[#1C1917] font-bold tracking-tight">
              Koleksi Kopi & Pastry Nami
            </h2>
          </div>

          {/* Search Bar */}
          <div className="relative w-full md:w-72">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#78716C]" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Cari rasa, bean, atau menu..."
              className="w-full pl-9 pr-4 py-2 text-xs bg-white border border-[#DDD3C7] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#8C6D53] placeholder:text-[#A8A29E]"
            />
          </div>
        </div>

        {/* Filter Segmented Controls */}
        <div className="flex items-center gap-1.5 p-1.5 bg-[#EAE2D7] rounded-xl overflow-x-auto scrollbar-none mb-10">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id as CategoryType)}
              className={`px-3.5 py-2 text-xs font-semibold rounded-lg transition-all whitespace-nowrap shrink-0 ${
                activeCategory === cat.id
                  ? 'bg-white text-[#1C1917] shadow-xs'
                  : 'text-[#57534E] hover:text-[#1C1917] hover:bg-white/50'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Product Cards Grid: 3-column desktop, 2-column tablet */}
        {filteredProducts.length === 0 ? (
          <div className="text-center py-16 bg-[#F4EFEB] rounded-2xl border border-dashed border-[#DDD3C7]">
            <Coffee className="w-10 h-10 text-[#A8A29E] mx-auto mb-3" />
            <p className="text-sm font-semibold text-[#1C1917]">
              Menu tidak ditemukan
            </p>
            <p className="text-xs text-[#78716C] mt-1">
              Coba kata kunci lain atau pilih kategori "Semua Menu"
            </p>
            <button
              onClick={() => {
                setActiveCategory('all');
                setSearchQuery('');
              }}
              className="mt-4 px-4 py-1.5 text-xs font-semibold bg-[#1C1917] text-white rounded-md"
            >
              Reset Filter
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            {filteredProducts.map((product) => (
              <div
                key={product.id}
                className="group flex flex-col bg-white rounded-2xl border border-[#E8E1D9] overflow-hidden hover:border-[#D6CCC2] hover:shadow-md transition-all duration-300"
              >
                {/* Product Image: 65-75% visual weight */}
                <div 
                  className="relative aspect-[4/3] bg-[#EAE0D3] overflow-hidden cursor-pointer"
                  onClick={() => onSelectProduct(product)}
                >
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover object-center group-hover:scale-103 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                    loading="lazy"
                  />

                  {/* Fallback pattern if image is missing */}
                  <div className="absolute inset-0 bg-[#EAE0D3] -z-10 flex items-center justify-center text-[#78716C]">
                    <Coffee className="w-8 h-8" />
                  </div>

                  {/* Minimal editorial text tag (max 1 tag) */}
                  {product.badge && (
                    <div className="absolute top-3 left-3 bg-[#1C1917]/85 backdrop-blur-xs text-white text-[10px] font-sans font-medium px-2 py-0.5 rounded-sm">
                      {product.badge}
                    </div>
                  )}

                  {/* Japanese subtitle overlay */}
                  <div className="absolute bottom-2.5 right-3 text-white/90 text-[11px] font-mono tracking-wider bg-black/40 px-1.5 py-0.5 rounded-xs backdrop-blur-xs">
                    {product.japaneseName}
                  </div>
                </div>

                {/* Card Details */}
                <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                  <div className="space-y-1.5">
                    {/* Unboxed metadata with typographic separators */}
                    <div className="flex items-center gap-1.5 text-[11px] text-[#78716C] font-mono">
                      <span>{product.category.toUpperCase()}</span>
                      {product.origin && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="truncate max-w-[160px]">{product.origin}</span>
                        </>
                      )}
                    </div>

                    {/* Title */}
                    <h3 
                      onClick={() => onSelectProduct(product)}
                      className="font-serif text-lg font-bold text-[#1C1917] leading-snug cursor-pointer group-hover:text-[#B45309] transition-colors"
                    >
                      {product.name}
                    </h3>

                    {/* Tasting notes */}
                    <p className="text-xs text-[#57534E] leading-relaxed line-clamp-2">
                      {product.description}
                    </p>

                    {/* Tasting Notes tags */}
                    <div className="pt-2 flex flex-wrap items-center gap-1.5 text-[11px] text-[#8C6D53]">
                      {product.notes.map((note, idx) => (
                        <span key={note} className="bg-[#FAF6F0] px-2 py-0.5 rounded text-[10px] border border-[#EAE2D7]">
                          {note}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Price & Action Row */}
                  <div className="pt-3 border-t border-[#F2ECE4] flex items-center justify-between gap-3">
                    <div>
                      <p className="text-[10px] text-[#78716C] uppercase font-mono">Harga</p>
                      <p className="font-mono text-base font-bold text-[#1C1917] tabular-nums">
                        Rp {product.price.toLocaleString('id-ID')}
                      </p>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => onSelectProduct(product)}
                        className="px-3 py-1.5 text-xs font-semibold text-[#1C1917] bg-[#F4EFEB] hover:bg-[#EAE0D3] rounded-md transition-colors"
                      >
                        Kustomisasi
                      </button>

                      <button
                        onClick={() => onQuickAdd(product)}
                        aria-label={`Tambah ${product.name} ke pesanan`}
                        className="p-2 text-white bg-[#1C1917] hover:bg-[#B45309] rounded-md transition-all shadow-2xs active:scale-95"
                      >
                        <Plus className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>

              </div>
            ))}
          </div>
        )}

      </div>
    </section>
  );
};
