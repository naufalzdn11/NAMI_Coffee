import React from 'react';
import { ArrowRight, Sparkles, Coffee } from 'lucide-react';

interface HeroSectionProps {
  onExploreMenu: () => void;
  onOpenBrewGuide: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onExploreMenu,
  onOpenBrewGuide,
}) => {
  return (
    <section className="relative overflow-hidden pt-8 pb-16 lg:pt-14 lg:pb-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Split Grid Hero: Content Left, Cinematic Image Right */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-center">
          
          {/* Left Column: Text & Intent */}
          <div className="lg:col-span-6 space-y-7">
            {/* Editorial kicker (Clean unboxed text, no pills) */}
            <div className="flex items-center gap-2.5 text-xs font-semibold text-[#8C6D53] tracking-widest uppercase font-sans">
              <span>Specialty Coffee Roastery</span>
              <span aria-hidden="true">·</span>
              <span>Jakarta & Bali</span>
            </div>

            {/* Main Headline: balanced, non-orphaned */}
            <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl text-[#1C1917] tracking-tight leading-[1.12]" style={{ textWrap: 'balance' }}>
              Ketenangan dalam Setiap Seduhan.
            </h1>

            {/* Lead Narrative */}
            <p className="text-base sm:text-lg text-[#57534E] leading-relaxed max-w-xl font-normal">
              NAMI (波) berarti gelombang — sebuah undangan untuk melambatkan ritme, 
              merasakan aroma kopi kurasi single origin terbaik dunia, dan menikmati 
              pastry mentega fermentasi artisanal dalam ruang yang hening dan hangat.
            </p>

            {/* CTAs */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={onExploreMenu}
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 text-sm font-semibold text-[#FAF8F5] bg-[#1C1917] rounded-md hover:bg-[#2E2A27] transition-all shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-700 active:scale-98"
              >
                <span>Lihat Menu & Pesan</span>
                <ArrowRight className="w-4 h-4 text-amber-200" />
              </button>

              <button
                onClick={onOpenBrewGuide}
                className="inline-flex items-center justify-center gap-2 px-5 py-3.5 text-sm font-medium text-[#1C1917] bg-[#F2ECE4] border border-[#DDD3C7] rounded-md hover:bg-[#EAE0D3] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-700"
              >
                <Coffee className="w-4 h-4 text-[#78716C]" />
                <span>Kalkulator Seduh V60</span>
              </button>
            </div>

            {/* Editorial Meta Specs */}
            <div className="pt-4 border-t border-[#E8E1D9] grid grid-cols-3 gap-4 text-left">
              <div>
                <p className="font-mono text-xl sm:text-2xl font-bold text-[#1C1917] tabular-nums">
                  88.5+
                </p>
                <p className="text-xs text-[#78716C] mt-0.5">SCA Cupping Score</p>
              </div>
              <div>
                <p className="font-mono text-xl sm:text-2xl font-bold text-[#1C1917] tabular-nums">
                  100%
                </p>
                <p className="text-xs text-[#78716C] mt-0.5">Etis Single Origin</p>
              </div>
              <div>
                <p className="font-mono text-xl sm:text-2xl font-bold text-[#1C1917] tabular-nums">
                  48 Jam
                </p>
                <p className="text-xs text-[#78716C] mt-0.5">Fermentasi Brioche</p>
              </div>
            </div>
          </div>

          {/* Right Column: High-Fidelity Image with Frame Integrity */}
          <div className="lg:col-span-6 relative">
            <div className="relative rounded-2xl overflow-hidden shadow-xl aspect-[16/10] bg-[#EAE0D3] border border-[#E0D7CB]">
              <img
                src="/src/assets/images/hero_nami_coffee_1792994781675.jpg"
                alt="Interior kedai kopi NAMI Coffee dengan barista menyeduh pour over di atas meja kayu minimalis Jepang"
                className="w-full h-full object-cover object-center transform hover:scale-102 transition-transform duration-700"
                referrerPolicy="no-referrer"
                loading="eager"
              />

              {/* Quiet editorial photo caption overlay */}
              <div className="absolute bottom-0 inset-x-0 p-4 sm:p-5 bg-gradient-to-t from-black/75 via-black/35 to-transparent text-white">
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="font-medium tracking-wide">NAMI ATELIER · BAR SENOPATI</span>
                  <span className="opacity-80">SEDANG BERLANGSUNG</span>
                </div>
              </div>
            </div>

            {/* Subtle decorative accent leaf or label */}
            <div className="absolute -bottom-4 -left-4 sm:-bottom-5 sm:-left-5 bg-[#FAF8F5] border border-[#E0D7CB] rounded-xl p-4 shadow-lg hidden sm:flex items-center gap-3 max-w-xs">
              <div className="w-10 h-10 rounded-lg bg-[#FAF0E6] flex items-center justify-center shrink-0">
                <Sparkles className="w-5 h-5 text-[#B45309]" />
              </div>
              <div>
                <p className="text-xs font-bold text-[#1C1917]">Fresh Micro-Batch</p>
                <p className="text-[11px] text-[#78716C]">Disangrai segar setiap Selasa & Jumat</p>
              </div>
            </div>
          </div>

        </div>

        {/* 4-Column Proof Row below the hero split */}
        <div className="mt-14 pt-8 border-t border-[#E8E1D9] grid grid-cols-2 md:grid-cols-4 gap-6 sm:gap-8">
          <div>
            <p className="text-xs font-bold uppercase tracking-wider text-[#78716C]">Direct Trade</p>
            <p className="text-sm font-medium text-[#1C1917] mt-1">Bermitra langsung dengan petani di Gayo, Huila, & Kintamani</p>
          </div>
          <div>
            <p className="text-xs font-bold uppercase tracking-wider text-[#78716C]">Precision Roasting</p>
            <p className="text-sm font-medium text-[#1C1917] mt-1">Profil sangrai terkalibrasi mesin Loring S15 Kestrel</p>
          </div>
          <div>
            <p className="text-xs font-bold uppercase tracking-wider text-[#78716C]">Pure Ingredients</p>
            <p className="text-sm font-medium text-[#1C1917] mt-1">Gula kelapa organik, sea salt Maldon, & susu plant-based premium</p>
          </div>
          <div>
            <p className="text-xs font-bold uppercase tracking-wider text-[#78716C]">Jam Buka Kafe</p>
            <p className="text-sm font-medium text-[#1C1917] mt-1">Buka setiap hari mulai 07:00 hingga 22:00 WIB</p>
          </div>
        </div>
      </div>
    </section>
  );
};
