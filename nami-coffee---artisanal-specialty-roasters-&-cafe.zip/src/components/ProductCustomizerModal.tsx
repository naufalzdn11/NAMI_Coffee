import React, { useState } from 'react';
import { X, Plus, Minus, Check, Coffee } from 'lucide-react';
import { Product, CartItem } from '../data/coffeeData';

interface ProductCustomizerModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (item: CartItem) => void;
}

export const ProductCustomizerModal: React.FC<ProductCustomizerModalProps> = ({
  product,
  onClose,
  onAddToCart
}) => {
  if (!product) return null;

  const isDrink = product.category === 'signature' || product.category === 'espresso' || product.category === 'manual';
  const isBean = product.category === 'beans';

  const [quantity, setQuantity] = useState(1);
  const [temperature, setTemperature] = useState<'Iced' | 'Hot'>('Iced');
  const [sweetness, setSweetness] = useState<'Normal (100%)' | 'Less Sugar (50%)' | 'No Sugar (0%)'>('Normal (100%)');
  const [milk, setMilk] = useState<'Fresh Milk' | 'Oat Milk (+Rp 8.000)' | 'Almond Milk (+Rp 8.000)'>('Fresh Milk');
  const [grindSize, setGrindSize] = useState<'Whole Bean (Biji Utuh)' | 'V60 / Pour Over' | 'AeroPress' | 'Espresso Machine' | 'Cold Brew Coarse'>('Whole Bean (Biji Utuh)');
  const [notes, setNotes] = useState('');
  const [addedSuccess, setAddedSuccess] = useState(false);

  // Compute unit price
  let additionalCost = 0;
  if (isDrink && (milk.includes('Oat Milk') || milk.includes('Almond Milk'))) {
    additionalCost += 8000;
  }
  const unitPrice = product.price + additionalCost;
  const totalPrice = unitPrice * quantity;

  const handleAdd = () => {
    const item: CartItem = {
      cartItemId: `${product.id}-${Date.now()}`,
      product,
      quantity,
      temperature: isDrink ? temperature : undefined,
      sweetness: isDrink ? sweetness : undefined,
      milk: isDrink && product.category !== 'manual' ? milk : undefined,
      grindSize: isBean ? grindSize : undefined,
      notes: notes.trim() || undefined,
      unitPrice
    };

    onAddToCart(item);
    setAddedSuccess(true);
    setTimeout(() => {
      setAddedSuccess(false);
      onClose();
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div 
        className="relative w-full max-w-lg bg-[#FAF8F5] rounded-2xl shadow-2xl border border-[#E0D7CB] overflow-hidden max-h-[92vh] flex flex-col animate-in fade-in zoom-in-95 duration-200"
        role="dialog"
        aria-modal="true"
        aria-labelledby="customizer-title"
      >
        {/* Header with image preview banner */}
        <div className="relative h-44 sm:h-52 bg-[#EAE0D3] shrink-0 overflow-hidden">
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover object-center"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#1C1917]/80 via-black/30 to-transparent" />
          
          <button
            onClick={onClose}
            className="absolute top-3.5 right-3.5 p-2 rounded-full bg-black/50 text-white hover:bg-black/80 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white"
            aria-label="Tutup dialog"
          >
            <X className="w-4 h-4" />
          </button>

          <div className="absolute bottom-3 left-4 right-4 text-white">
            <span className="text-[11px] font-mono tracking-widest uppercase opacity-80">
              {product.japaneseName}
            </span>
            <h3 id="customizer-title" className="font-serif text-xl sm:text-2xl font-bold leading-tight mt-0.5">
              {product.name}
            </h3>
            <div className="flex items-center gap-2 mt-1 text-xs opacity-90">
              {product.notes.map((note, idx) => (
                <React.Fragment key={note}>
                  <span>{note}</span>
                  {idx < product.notes.length - 1 && <span aria-hidden="true">·</span>}
                </React.Fragment>
              ))}
            </div>
          </div>
        </div>

        {/* Scrollable Configuration Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-5 text-sm text-[#44403C]">
          <p className="text-xs text-[#78716C] leading-relaxed">
            {product.description}
          </p>

          {/* Temperature Options */}
          {isDrink && product.category !== 'manual' && (
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-[#1C1917] mb-2">
                Suhu Penyajian
              </label>
              <div className="grid grid-cols-2 gap-2">
                {(['Iced', 'Hot'] as const).map((temp) => (
                  <button
                    key={temp}
                    type="button"
                    onClick={() => setTemperature(temp)}
                    className={`py-2 px-3 rounded-lg text-xs font-semibold border transition-all text-center ${
                      temperature === temp
                        ? 'bg-[#1C1917] text-white border-[#1C1917] shadow-xs'
                        : 'bg-[#F4EFEB] text-[#57534E] border-[#DDD3C7] hover:bg-[#EAE0D3]'
                    }`}
                  >
                    {temp === 'Iced' ? 'Dingin (Iced)' : 'Hangat (Hot)'}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Sweetness Options */}
          {isDrink && product.category !== 'manual' && (
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-[#1C1917] mb-2">
                Tingkat Kemanisan
              </label>
              <div className="grid grid-cols-3 gap-2">
                {(['Normal (100%)', 'Less Sugar (50%)', 'No Sugar (0%)'] as const).map((lvl) => (
                  <button
                    key={lvl}
                    type="button"
                    onClick={() => setSweetness(lvl)}
                    className={`py-2 px-2 rounded-lg text-xs font-medium border transition-all text-center ${
                      sweetness === lvl
                        ? 'bg-[#1C1917] text-white border-[#1C1917] shadow-xs'
                        : 'bg-[#F4EFEB] text-[#57534E] border-[#DDD3C7] hover:bg-[#EAE0D3]'
                    }`}
                  >
                    {lvl}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Milk Options (for non-manual brews) */}
          {isDrink && product.category !== 'manual' && (
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-[#1C1917] mb-2">
                Pilihan Susu
              </label>
              <div className="space-y-1.5">
                {(['Fresh Milk', 'Oat Milk (+Rp 8.000)', 'Almond Milk (+Rp 8.000)'] as const).map((opt) => (
                  <label
                    key={opt}
                    onClick={() => setMilk(opt)}
                    className={`flex items-center justify-between p-2.5 rounded-lg border cursor-pointer transition-all ${
                      milk === opt
                        ? 'bg-[#F2ECE4] border-[#8C6D53] text-[#1C1917] font-semibold'
                        : 'bg-[#FAF8F5] border-[#E0D7CB] text-[#57534E] hover:bg-[#F4EFEB]'
                    }`}
                  >
                    <span className="text-xs">{opt}</span>
                    <input
                      type="radio"
                      name="milk-option"
                      checked={milk === opt}
                      onChange={() => setMilk(opt)}
                      className="accent-[#B45309]"
                    />
                  </label>
                ))}
              </div>
            </div>
          )}

          {/* Bean Grind Size */}
          {isBean && (
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-[#1C1917] mb-2">
                Tingkat Gilingan (Grind Size)
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {(
                  [
                    'Whole Bean (Biji Utuh)',
                    'V60 / Pour Over',
                    'AeroPress',
                    'Espresso Machine',
                    'Cold Brew Coarse'
                  ] as const
                ).map((g) => (
                  <button
                    key={g}
                    type="button"
                    onClick={() => setGrindSize(g)}
                    className={`p-2.5 rounded-lg text-xs font-medium border text-left transition-all ${
                      grindSize === g
                        ? 'bg-[#1C1917] text-white border-[#1C1917]'
                        : 'bg-[#F4EFEB] text-[#57534E] border-[#DDD3C7] hover:bg-[#EAE0D3]'
                    }`}
                  >
                    {g}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Notes for barista */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-[#1C1917] mb-1.5">
              Catatan Khusus Barista
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Contoh: Pisahkan es, minta sedotan ramah lingkungan..."
              className="w-full px-3 py-2 text-xs bg-white border border-[#DDD3C7] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#8C6D53]"
            />
          </div>
        </div>

        {/* Footer Actions with Total Calculation */}
        <div className="p-4 sm:p-5 border-t border-[#E8E1D9] bg-[#F7F3EE] flex items-center justify-between gap-4 shrink-0">
          {/* Quantity Stepper */}
          <div className="flex items-center border border-[#DDD3C7] rounded-lg bg-white overflow-hidden shadow-2xs">
            <button
              type="button"
              onClick={() => setQuantity(Math.max(1, quantity - 1))}
              disabled={quantity <= 1}
              className="p-2 text-[#57534E] hover:bg-[#F4EFEB] disabled:opacity-40 transition-colors"
              aria-label="Kurangi jumlah"
            >
              <Minus className="w-3.5 h-3.5" />
            </button>
            <span className="w-8 text-center text-xs font-mono font-bold text-[#1C1917] tabular-nums">
              {quantity}
            </span>
            <button
              type="button"
              onClick={() => setQuantity(quantity + 1)}
              className="p-2 text-[#57534E] hover:bg-[#F4EFEB] transition-colors"
              aria-label="Tambah jumlah"
            >
              <Plus className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Submit Button with Animated Check State */}
          <button
            type="button"
            onClick={handleAdd}
            disabled={addedSuccess}
            className={`flex-1 flex items-center justify-center gap-2 py-3 px-4 rounded-lg text-xs sm:text-sm font-semibold transition-all shadow-sm ${
              addedSuccess
                ? 'bg-emerald-700 text-white'
                : 'bg-[#1C1917] text-white hover:bg-[#2E2A27] active:scale-98'
            }`}
          >
            {addedSuccess ? (
              <>
                <Check className="w-4 h-4" />
                <span>Berhasil Ditambahkan!</span>
              </>
            ) : (
              <>
                <span>Tambah ke Pesanan ·</span>
                <span className="font-mono tabular-nums">
                  Rp {totalPrice.toLocaleString('id-ID')}
                </span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
