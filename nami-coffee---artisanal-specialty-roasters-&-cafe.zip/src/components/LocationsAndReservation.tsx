import React, { useState } from 'react';
import { MapPin, Clock, Phone, ExternalLink, Check, Calendar, Users, Sparkles } from 'lucide-react';
import { LOCATIONS } from '../data/coffeeData';

interface LocationsAndReservationProps {
  onOpenReservationWithLocation?: (locId: string) => void;
}

export const LocationsAndReservation: React.FC<LocationsAndReservationProps> = ({
  onOpenReservationWithLocation
}) => {
  const [selectedLocation, setSelectedLocation] = useState<'senopati' | 'canggu'>('senopati');
  const [resDate, setResDate] = useState('2026-10-27');
  const [resTime, setResTime] = useState('14:00');
  const [guests, setGuests] = useState(2);
  const [tableArea, setTableArea] = useState('Zen Corner (Quiet Work)');
  const [guestName, setGuestName] = useState('');
  const [guestPhone, setGuestPhone] = useState('');
  const [confirmedBooking, setConfirmedBooking] = useState<{
    id: string;
    branch: string;
    date: string;
    time: string;
    guests: number;
    area: string;
    name: string;
  } | null>(null);

  const handleBookingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!guestName.trim() || !guestPhone.trim()) return;

    const bookingId = `NAMI-${Math.floor(1000 + Math.random() * 9000)}`;
    const branchName = selectedLocation === 'senopati' ? 'NAMI Senopati, Jakarta' : 'NAMI Canggu, Bali';

    setConfirmedBooking({
      id: bookingId,
      branch: branchName,
      date: resDate,
      time: resTime,
      guests,
      area: tableArea,
      name: guestName.trim()
    });
  };

  return (
    <section id="lokasi" className="py-16 sm:py-24 border-t border-[#E8E1D9] bg-[#F7F3EE]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-2xl mx-auto text-center mb-12 sm:mb-16">
          <div className="flex items-center justify-center gap-2 text-xs font-semibold text-[#8C6D53] tracking-widest uppercase mb-2">
            <span>Kedai & Ruang Temu</span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl text-[#1C1917] font-bold tracking-tight">
            Kunjungi Sanctuary Kami
          </h2>
          <p className="mt-3 text-sm text-[#57534E] leading-relaxed">
            Dua ruang tenang yang dirancang dengan kayu hangat, cahaya alami, dan alunan musik lo-fi 
            untuk ruang kerja santai maupun temu wicara hangat.
          </p>
        </div>

        {/* 2-Column Split: Left Locations Card, Right Table Reservation System */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-start">
          
          {/* Left Column: Location Cards (6 cols) */}
          <div className="lg:col-span-6 space-y-6">
            {LOCATIONS.map((loc) => (
              <div
                key={loc.id}
                className={`p-6 sm:p-7 rounded-2xl border transition-all duration-300 ${
                  selectedLocation === loc.id
                    ? 'bg-white border-[#8C6D53] shadow-md ring-1 ring-[#8C6D53]/20'
                    : 'bg-[#FAF8F5] border-[#E0D7CB] hover:bg-white hover:border-[#D6CCC2]'
                }`}
                onClick={() => setSelectedLocation(loc.id as any)}
              >
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <span className="text-[10px] font-mono tracking-widest uppercase text-[#8C6D53] font-bold">
                      {loc.city}
                    </span>
                    <h3 className="font-serif text-xl font-bold text-[#1C1917] mt-0.5">
                      {loc.name}
                    </h3>
                  </div>

                  <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-mono font-medium bg-emerald-50 text-emerald-800 border border-emerald-200">
                    Buka Sekarang
                  </span>
                </div>

                <div className="mt-4 space-y-2.5 text-xs text-[#57534E]">
                  <div className="flex items-center gap-2">
                    <MapPin className="w-3.5 h-3.5 text-[#8C6D53] shrink-0" />
                    <span>{loc.address}, {loc.city}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="w-3.5 h-3.5 text-[#8C6D53] shrink-0" />
                    <span>{loc.hours}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Phone className="w-3.5 h-3.5 text-[#8C6D53] shrink-0" />
                    <span className="font-mono">{loc.phone}</span>
                  </div>
                </div>

                {/* Amenities unboxed tags */}
                <div className="mt-4 pt-3 border-t border-[#F2ECE4] flex flex-wrap gap-1.5">
                  {loc.amenities.map((item) => (
                    <span
                      key={item}
                      className="px-2 py-0.5 text-[10px] bg-[#F5EFEB] text-[#57534E] rounded border border-[#E8E1D9]"
                    >
                      {item}
                    </span>
                  ))}
                </div>

                <div className="mt-5 flex items-center justify-between">
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedLocation(loc.id as any);
                    }}
                    className={`text-xs font-semibold px-3 py-1.5 rounded-md transition-colors ${
                      selectedLocation === loc.id
                        ? 'bg-[#1C1917] text-white'
                        : 'bg-[#F2ECE4] text-[#1C1917] hover:bg-[#EAE0D3]'
                    }`}
                  >
                    {selectedLocation === loc.id ? 'Cabang Terpilih' : 'Pilih Cabang Ini'}
                  </button>

                  <a
                    href={loc.googleMapsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={(e) => e.stopPropagation()}
                    className="inline-flex items-center gap-1 text-xs font-medium text-[#8C6D53] hover:text-[#1C1917]"
                  >
                    <span>Petunjuk Arah Maps</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
            ))}
          </div>

          {/* Right Column: Table Reservation Module (6 cols) */}
          <div className="lg:col-span-6 bg-white rounded-2xl border border-[#E0D7CB] p-6 sm:p-8 shadow-xs">
            <div className="flex items-center justify-between pb-4 border-b border-[#E8E1D9]">
              <div>
                <p className="text-xs font-bold uppercase tracking-wider text-[#8C6D53]">
                  Reservasi Meja
                </p>
                <h3 className="font-serif text-2xl font-bold text-[#1C1917]">
                  Pesan Meja Anda
                </h3>
              </div>
              <Calendar className="w-6 h-6 text-[#8C6D53]" />
            </div>

            {confirmedBooking ? (
              <div className="mt-6 p-6 bg-[#FAF6F0] rounded-xl border border-[#E0D7CB] text-center space-y-4 animate-in fade-in">
                <div className="w-12 h-12 bg-emerald-100 text-emerald-800 rounded-full flex items-center justify-center mx-auto">
                  <Check className="w-6 h-6" />
                </div>
                <div>
                  <span className="text-xs font-mono text-[#8C6D53] uppercase tracking-wider">
                    Tiket Terkonfirmasi
                  </span>
                  <h4 className="font-serif text-xl font-bold text-[#1C1917] mt-0.5">
                    Reservasi Berhasil!
                  </h4>
                  <p className="text-xs text-[#78716C] mt-1">
                    Kode Tiket: <strong className="font-mono text-[#1C1917]">{confirmedBooking.id}</strong>
                  </p>
                </div>

                <div className="text-left bg-white p-4 rounded-lg border border-[#E8E1D9] text-xs space-y-2">
                  <div className="flex justify-between">
                    <span className="text-[#78716C]">Lokasi:</span>
                    <span className="font-semibold text-[#1C1917]">{confirmedBooking.branch}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#78716C]">Jadwal:</span>
                    <span className="font-semibold text-[#1C1917]">{confirmedBooking.date} · {confirmedBooking.time} WIB</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#78716C]">Jumlah Tamu:</span>
                    <span className="font-semibold text-[#1C1917]">{confirmedBooking.guests} Orang ({confirmedBooking.area})</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#78716C]">Nama Pemesan:</span>
                    <span className="font-semibold text-[#1C1917]">{confirmedBooking.name}</span>
                  </div>
                </div>

                <p className="text-[11px] text-[#78716C]">
                  Konfirmasi otomatis telah dicatat di sistem reservasi barista kami. 
                  Meja Anda akan ditahan hingga 15 menit dari jam kedatangan.
                </p>

                <button
                  type="button"
                  onClick={() => setConfirmedBooking(null)}
                  className="px-4 py-2 text-xs font-semibold bg-[#1C1917] text-white rounded-md hover:bg-[#2E2A27]"
                >
                  Buat Reservasi Baru
                </button>
              </div>
            ) : (
              <form onSubmit={handleBookingSubmit} className="mt-6 space-y-4 text-xs">
                
                {/* Branch reminder */}
                <div className="p-2.5 bg-[#FAF8F5] rounded-lg border border-[#E8E1D9] flex items-center justify-between">
                  <span className="text-[#78716C]">Cabang Pilihan:</span>
                  <span className="font-bold text-[#1C1917]">
                    {selectedLocation === 'senopati' ? 'Senopati, Jakarta Selatan' : 'Canggu, Bali'}
                  </span>
                </div>

                {/* Date & Time */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[#1C1917] font-bold uppercase tracking-wider mb-1">
                      Tanggal
                    </label>
                    <input
                      type="date"
                      value={resDate}
                      onChange={(e) => setResDate(e.target.value)}
                      required
                      className="w-full px-3 py-2 bg-white border border-[#DDD3C7] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#8C6D53]"
                    />
                  </div>

                  <div>
                    <label className="block text-[#1C1917] font-bold uppercase tracking-wider mb-1">
                      Jam Kedatangan
                    </label>
                    <select
                      value={resTime}
                      onChange={(e) => setResTime(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-[#DDD3C7] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#8C6D53]"
                    >
                      {['08:00', '10:00', '12:00', '14:00', '16:00', '18:00', '20:00'].map((t) => (
                        <option key={t} value={t}>{t} WIB</option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Number of Guests & Area */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[#1C1917] font-bold uppercase tracking-wider mb-1">
                      Jumlah Tamu
                    </label>
                    <div className="flex items-center border border-[#DDD3C7] rounded-lg bg-white overflow-hidden">
                      <button
                        type="button"
                        onClick={() => setGuests(Math.max(1, guests - 1))}
                        className="p-2 text-[#78716C] hover:bg-[#F2ECE4]"
                      >
                        -
                      </button>
                      <span className="flex-1 text-center font-mono font-bold">{guests} Orang</span>
                      <button
                        type="button"
                        onClick={() => setGuests(Math.min(10, guests + 1))}
                        className="p-2 text-[#78716C] hover:bg-[#F2ECE4]"
                      >
                        +
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="block text-[#1C1917] font-bold uppercase tracking-wider mb-1">
                      Zona Duduk
                    </label>
                    <select
                      value={tableArea}
                      onChange={(e) => setTableArea(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-[#DDD3C7] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#8C6D53]"
                    >
                      <option value="Zen Corner (Quiet Work)">Zen Corner (Fokus Kerja)</option>
                      <option value="Barista Pour-over Counter">Barista Counter (Live Drip)</option>
                      <option value="Outdoor Sun Patio">Outdoor Garden (Santai)</option>
                      <option value="Main Dining Hall">Ruang Utama</option>
                    </select>
                  </div>
                </div>

                {/* Customer Contact */}
                <div>
                  <label className="block text-[#1C1917] font-bold uppercase tracking-wider mb-1">
                    Nama Pemesan
                  </label>
                  <input
                    type="text"
                    required
                    value={guestName}
                    onChange={(e) => setGuestName(e.target.value)}
                    placeholder="Contoh: Rian Anggara"
                    className="w-full px-3 py-2 bg-white border border-[#DDD3C7] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#8C6D53]"
                  />
                </div>

                <div>
                  <label className="block text-[#1C1917] font-bold uppercase tracking-wider mb-1">
                    Nomor WhatsApp
                  </label>
                  <input
                    type="tel"
                    required
                    value={guestPhone}
                    onChange={(e) => setGuestPhone(e.target.value)}
                    placeholder="Contoh: 0812-3456-7890"
                    className="w-full px-3 py-2 bg-white border border-[#DDD3C7] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#8C6D53]"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3 px-4 rounded-lg text-xs font-semibold text-white bg-[#1C1917] hover:bg-[#2E2A27] transition-all shadow-sm active:scale-98 mt-2"
                >
                  Konfirmasi Reservasi Meja Sekarang
                </button>
              </form>
            )}

          </div>

        </div>

      </div>
    </section>
  );
};
