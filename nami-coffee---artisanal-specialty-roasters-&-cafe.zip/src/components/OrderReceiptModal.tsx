import React from 'react';
import { X, Check, MessageSquare, Printer, Coffee } from 'lucide-react';
import { CartItem } from '../data/coffeeData';

interface OrderReceiptModalProps {
  order: {
    orderId: string;
    customerName: string;
    customerPhone: string;
    orderType: 'Dine-In' | 'Takeaway' | 'Delivery';
    tableOrAddress: string;
    items: CartItem[];
    subtotal: number;
    tax: number;
    total: number;
  } | null;
  onClose: () => void;
}

export const OrderReceiptModal: React.FC<OrderReceiptModalProps> = ({ order, onClose }) => {
  if (!order) return null;

  // Generate WhatsApp message
  const waText = `Halo Barista NAMI Coffee,%0ASaya ingin mengonfirmasi pesanan saya:%0A%0A*ID Pesanan:* ${order.orderId}%0A*Tipe:* ${order.orderType} (${order.tableOrAddress})%0A*Nama:* ${order.customerName}%0A*No WA:* ${order.customerPhone}%0A%0A*Rincian Menu:*%0A${order.items.map((i) => `- ${i.quantity}x ${i.product.name} (${i.temperature || ''} ${i.sweetness || ''} ${i.milk || ''}) = Rp ${(i.unitPrice * i.quantity).toLocaleString('id-ID')}`).join('%0A')}%0A%0A*Total Bayar:* Rp ${order.total.toLocaleString('id-ID')}%0A%0AMohon diproses, terima kasih!`;

  const waUrl = `https://wa.me/6281288904411?text=${waText}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div 
        className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl border border-[#E0D7CB] overflow-hidden flex flex-col max-h-[92vh] animate-in fade-in zoom-in-95 duration-200"
        role="dialog"
        aria-modal="true"
        aria-labelledby="receipt-title"
      >
        {/* Top Header */}
        <div className="bg-[#1C1917] text-[#FAF8F5] p-5 text-center relative shrink-0">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 text-stone-400 hover:text-white rounded-md transition-colors"
            aria-label="Tutup kuitansi"
          >
            <X className="w-5 h-5" />
          </button>
          
          <div className="w-10 h-10 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto mb-2 border border-emerald-500/30">
            <Check className="w-5 h-5" />
          </div>

          <h3 id="receipt-title" className="font-serif text-xl font-bold">
            Pesanan Diterima!
          </h3>
          <p className="text-xs text-stone-300 mt-0.5">
            Nomor Tiket: <span className="font-mono font-bold text-amber-300">{order.orderId}</span>
          </p>
        </div>

        {/* Receipt Slip Body */}
        <div className="p-6 overflow-y-auto space-y-5 text-xs text-[#44403C] bg-[#FAF8F5]">
          
          {/* Metadata Grid */}
          <div className="p-3.5 bg-white rounded-xl border border-[#E8E1D9] space-y-1.5 font-mono text-[11px]">
            <div className="flex justify-between">
              <span className="text-[#78716C]">WAKTU:</span>
              <span className="font-semibold text-[#1C1917]">{new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })} WIB</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#78716C]">JENIS LAYANAN:</span>
              <span className="font-semibold text-[#1C1917]">{order.orderType} · {order.tableOrAddress}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#78716C]">PELANGGAN:</span>
              <span className="font-semibold text-[#1C1917]">{order.customerName} ({order.customerPhone})</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#78716C]">STATUS:</span>
              <span className="text-emerald-700 font-bold">Mengantre di Bar</span>
            </div>
          </div>

          {/* Itemized Table */}
          <div className="space-y-2">
            <p className="font-bold uppercase tracking-wider text-[#78716C] text-[10px]">
              Daftar Pesanan
            </p>
            <div className="divide-y divide-[#E8E1D9] border-y border-[#E8E1D9] py-1">
              {order.items.map((item) => (
                <div key={item.cartItemId} className="py-2 flex justify-between items-start">
                  <div>
                    <p className="font-semibold text-[#1C1917]">
                      {item.quantity}x {item.product.name}
                    </p>
                    <div className="text-[10px] text-[#78716C]">
                      {item.temperature && <span>{item.temperature} · </span>}
                      {item.sweetness && <span>{item.sweetness} · </span>}
                      {item.milk && <span>{item.milk}</span>}
                      {item.grindSize && <span>{item.grindSize}</span>}
                    </div>
                  </div>
                  <span className="font-mono tabular-nums text-right font-medium">
                    Rp {(item.unitPrice * item.quantity).toLocaleString('id-ID')}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Totals */}
          <div className="space-y-1.5 font-mono text-[11px] pt-1">
            <div className="flex justify-between text-[#78716C]">
              <span>Subtotal</span>
              <span className="tabular-nums">Rp {order.subtotal.toLocaleString('id-ID')}</span>
            </div>
            <div className="flex justify-between text-[#78716C]">
              <span>Pajak Restoran (10%)</span>
              <span className="tabular-nums">Rp {order.tax.toLocaleString('id-ID')}</span>
            </div>
            <div className="flex justify-between font-bold text-sm text-[#1C1917] pt-2 border-t border-[#DDD3C7]">
              <span>Total Akhir</span>
              <span className="tabular-nums text-[#B45309]">
                Rp {order.total.toLocaleString('id-ID')}
              </span>
            </div>
          </div>

          {/* Barista notice */}
          <div className="p-3 bg-amber-50/70 border border-amber-200/60 rounded-lg text-[11px] text-amber-900 leading-relaxed">
            Pesanan Anda telah dikirimkan ke mesin kasir barista NAMI. Tunjukkan kode tiket ini kepada staf saat pelunasan di kasir atau pembayaran QRIS.
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-white border-t border-[#E8E1D9] flex flex-col gap-2 shrink-0">
          <a
            href={waUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-lg text-xs flex items-center justify-center gap-2 transition-colors"
          >
            <MessageSquare className="w-4 h-4" />
            <span>Kirim Konfirmasi via WhatsApp (+62 812-8890-4411)</span>
          </a>

          <div className="flex items-center gap-2">
            <button
              onClick={() => window.print()}
              className="flex-1 py-2 px-3 border border-[#DDD3C7] text-[#57534E] hover:bg-[#F2ECE4] rounded-lg text-xs font-medium flex items-center justify-center gap-1.5 transition-colors"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Cetak Bukti</span>
            </button>
            <button
              onClick={onClose}
              className="flex-1 py-2 px-3 bg-[#1C1917] text-white hover:bg-[#2E2A27] rounded-lg text-xs font-semibold transition-colors"
            >
              Selesai & Tutup
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
