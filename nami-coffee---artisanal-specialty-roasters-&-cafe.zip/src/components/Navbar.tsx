import React, { useState } from 'react';
import { ShoppingBag, Calendar, Menu as MenuIcon, X } from 'lucide-react';

interface NavbarProps {
  cartCount: number;
  onOpenCart: () => void;
  onOpenReservation: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  cartCount,
  onOpenCart,
  onOpenReservation
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-[#FAF8F5]/95 backdrop-blur-md border-b border-[#E8E1D9] transition-all duration-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-8">
        {/* Zone 1: Brand wordmark (single line, no descriptor clutter) */}
        <a 
          href="#" 
          className="flex items-center gap-2.5 text-slate-900 group whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-700 rounded-sm"
        >
          <div className="w-9 h-9 rounded-full bg-[#1C1917] text-[#FAF8F5] flex items-center justify-center font-serif text-lg font-bold shadow-sm transition-transform group-hover:scale-105">
            波
          </div>
          <div className="flex flex-col">
            <span className="font-serif text-xl tracking-tight font-bold text-[#1C1917]">
              NAMI COFFEE
            </span>
            <span className="text-[10px] tracking-widest text-[#78716C] -mt-1 font-sans uppercase">
              Roasters & Atelier
            </span>
          </div>
        </a>

        {/* Zone 2: 4-5 clean single-line nav links */}
        <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-[#57534E]">
          <a
            href="#menu"
            className="hover:text-[#1C1917] transition-colors whitespace-nowrap shrink-0 py-1"
          >
            Menu & Minuman
          </a>
          <a
            href="#beans"
            className="hover:text-[#1C1917] transition-colors whitespace-nowrap shrink-0 py-1"
          >
            Biji Kopi
          </a>
          <a
            href="#brew-guide"
            className="hover:text-[#1C1917] transition-colors whitespace-nowrap shrink-0 py-1"
          >
            Brew Guide
          </a>
          <a
            href="#cerita"
            className="hover:text-[#1C1917] transition-colors whitespace-nowrap shrink-0 py-1"
          >
            Cerita Nami
          </a>
          <a
            href="#lokasi"
            className="hover:text-[#1C1917] transition-colors whitespace-nowrap shrink-0 py-1"
          >
            Lokasi & Jam
          </a>
        </nav>

        {/* Zone 3: Primary action & cart access */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={onOpenReservation}
            className="hidden sm:inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-[#1C1917] bg-[#F2ECE4] border border-[#DDD3C7] rounded-md hover:bg-[#EAE0D3] transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-700"
          >
            <Calendar className="w-3.5 h-3.5 text-[#78716C]" />
            <span>Reservasi Meja</span>
          </button>

          <button
            onClick={onOpenCart}
            aria-label={`Keranjang Belanja (${cartCount} item)`}
            className="relative inline-flex items-center gap-2.5 px-4 py-2 text-xs font-semibold text-white bg-[#1C1917] rounded-md hover:bg-[#2E2A27] transition-all whitespace-nowrap shrink-0 shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-700 active:scale-95"
          >
            <ShoppingBag className="w-4 h-4 text-amber-200" />
            <span className="hidden xs:inline">Pesanan</span>
            {cartCount > 0 ? (
              <span className="inline-flex items-center justify-center px-1.5 py-0.5 text-[11px] font-bold font-mono bg-[#B45309] text-white rounded-full min-w-5">
                {cartCount}
              </span>
            ) : (
              <span className="font-mono text-xs text-stone-400">0</span>
            )}
          </button>

          {/* Mobile hamburger */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 text-[#44403C] hover:text-[#1C1917] hover:bg-[#F2ECE4] rounded-md transition-colors"
            aria-label="Toggle Navigation Menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <MenuIcon className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-[#E8E1D9] bg-[#FAF8F5] px-6 py-4 space-y-3">
          <a
            href="#menu"
            onClick={() => setMobileMenuOpen(false)}
            className="block text-sm font-medium text-[#44403C] hover:text-[#1C1917] py-1.5"
          >
            Menu & Minuman
          </a>
          <a
            href="#beans"
            onClick={() => setMobileMenuOpen(false)}
            className="block text-sm font-medium text-[#44403C] hover:text-[#1C1917] py-1.5"
          >
            Biji Kopi
          </a>
          <a
            href="#brew-guide"
            onClick={() => setMobileMenuOpen(false)}
            className="block text-sm font-medium text-[#44403C] hover:text-[#1C1917] py-1.5"
          >
            Kalkulator Brew Guide
          </a>
          <a
            href="#cerita"
            onClick={() => setMobileMenuOpen(false)}
            className="block text-sm font-medium text-[#44403C] hover:text-[#1C1917] py-1.5"
          >
            Cerita Nami
          </a>
          <a
            href="#lokasi"
            onClick={() => setMobileMenuOpen(false)}
            className="block text-sm font-medium text-[#44403C] hover:text-[#1C1917] py-1.5"
          >
            Lokasi & Jam Operasional
          </a>
          <div className="pt-2 border-t border-[#E8E1D9]">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenReservation();
              }}
              className="w-full py-2.5 text-center text-xs font-semibold text-[#1C1917] bg-[#F2ECE4] rounded-md hover:bg-[#EAE0D3]"
            >
              Reservasi Meja
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
