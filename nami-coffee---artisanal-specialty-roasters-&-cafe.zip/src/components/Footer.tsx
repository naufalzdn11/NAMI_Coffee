import React, { useState } from 'react';
import { ArrowRight, Check } from 'lucide-react';

export const Footer: React.FC = () => {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !email.includes('@')) return;
    setSubscribed(true);
  };

  return (
    <footer className="bg-[#1C1917] text-[#FAF8F5] pt-16 pb-12 border-t border-stone-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Tier: Brand & Newsletter */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 pb-14 border-b border-stone-800">
          
          <div className="lg:col-span-5 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-[#FAF8F5] text-[#1C1917] flex items-center justify-center font-serif text-base font-bold">
                波
              </div>
              <span className="font-serif text-xl tracking-tight font-bold">
                NAMI COFFEE
              </span>
            </div>
            <p className="text-xs text-stone-400 leading-relaxed max-w-sm">
              Artisanal Specialty Coffee Roastery & Atelier. Menghadirkan biji kopi terkurasi etis, 
              ekstraksi presisi, dan pastry mentega fermentasi alami di Jakarta dan Bali.
            </p>
            <p className="text-[11px] font-mono text-stone-500">
              SENOPATI · JAKARTA · CANGGU · BALI
            </p>
          </div>

          {/* Newsletter Box */}
          <div className="lg:col-span-7 space-y-3">
            <p className="text-xs font-bold uppercase tracking-wider text-amber-300/90 font-mono">
              Warta Seduhan & Undangan Cupping
            </p>
            <p className="text-sm text-stone-300">
              Dapatkan jadwal rilis micro-lot biji kopi langka dan undangan sesi cupping bulanan gratis bersama Head Roaster kami.
            </p>

            {subscribed ? (
              <div className="p-3 bg-emerald-950/60 border border-emerald-700/60 rounded-lg flex items-center gap-2 text-xs text-emerald-300">
                <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Terima kasih! Undangan cupping dan warta seduh pertama akan dikirim ke email Anda.</span>
              </div>
            ) : (
              <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-2 max-w-md">
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Masukkan alamat email Anda"
                  className="flex-1 px-3.5 py-2.5 text-xs bg-stone-900 border border-stone-700 rounded-lg text-white placeholder:text-stone-500 focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
                <button
                  type="submit"
                  className="px-4 py-2.5 text-xs font-semibold bg-[#FAF8F5] text-[#1C1917] rounded-lg hover:bg-stone-200 transition-colors whitespace-nowrap shrink-0 flex items-center justify-center gap-1.5"
                >
                  <span>Berlangganan</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </form>
            )}
          </div>

        </div>

        {/* Middle Tier: Directory Navigation */}
        <div className="py-10 grid grid-cols-2 md:grid-cols-4 gap-8 text-xs">
          <div>
            <h4 className="font-bold text-stone-200 uppercase tracking-wider text-[11px] mb-3">
              Koleksi Kopi
            </h4>
            <ul className="space-y-2 text-stone-400">
              <li><a href="#menu" className="hover:text-white transition-colors">Signature Cloud Latte</a></li>
              <li><a href="#menu" className="hover:text-white transition-colors">Single Origin V60 Filter</a></li>
              <li><a href="#menu" className="hover:text-white transition-colors">Kyoto 18h Cold Drip</a></li>
              <li><a href="#menu" className="hover:text-white transition-colors">Biji Kopi Micro-Lot (250g)</a></li>
              <li><a href="#menu" className="hover:text-white transition-colors">Artisanal Bakery & Brioche</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-stone-200 uppercase tracking-wider text-[11px] mb-3">
              Sanctuary Kami
            </h4>
            <ul className="space-y-2 text-stone-400">
              <li><a href="#lokasi" className="hover:text-white transition-colors">Senopati, Jakarta Selatan</a></li>
              <li><a href="#lokasi" className="hover:text-white transition-colors">Echo Beach, Canggu Bali</a></li>
              <li><a href="#lokasi" className="hover:text-white transition-colors">Reservasi Meja Kerja</a></li>
              <li><a href="#lokasi" className="hover:text-white transition-colors">Private Roastery Event</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-stone-200 uppercase tracking-wider text-[11px] mb-3">
              Eksplorasi Seduh
            </h4>
            <ul className="space-y-2 text-stone-400">
              <li><a href="#brew-guide" className="hover:text-white transition-colors">Kalkulator Seduh V60</a></li>
              <li><a href="#brew-guide" className="hover:text-white transition-colors">Rasio & Suhu Air Optimal</a></li>
              <li><a href="#cerita" className="hover:text-white transition-colors">Filosofi Ombak Tenang</a></li>
              <li><a href="#cerita" className="hover:text-white transition-colors">Standar Etika Direct Trade</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-stone-200 uppercase tracking-wider text-[11px] mb-3">
              Jam Operasional
            </h4>
            <div className="space-y-2 text-stone-400 text-[11px]">
              <p><strong className="text-stone-200">Senin – Minggu:</strong> 07:00 – 22:00 WIB</p>
              <p><strong className="text-stone-200">Baking Shift:</strong> 05:00 & 13:00</p>
              <p><strong className="text-stone-200">Kontak Kafe:</strong> +62 812-8890-4411</p>
              <p><strong className="text-stone-200">Email:</strong> hello@namicoffee.id</p>
            </div>
          </div>
        </div>

        {/* Bottom Tier: Copyright */}
        <div className="pt-8 border-t border-stone-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-stone-500 text-[11px]">
          <p>© 2026 NAMI Coffee Roasters & Atelier. Hak Cipta Dilindungi.</p>
          <div className="flex items-center gap-4">
            <span className="hover:text-stone-400 cursor-pointer">Kebijakan Privasi</span>
            <span aria-hidden="true">·</span>
            <span className="hover:text-stone-400 cursor-pointer">Syarat & Ketentuan</span>
            <span aria-hidden="true">·</span>
            <span>Crafted with Calm Intention</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
