import React, { useState, useEffect } from 'react';
import { Play, Pause, RotateCcw, Clock, Thermometer, Droplets, Sparkles, CheckCircle2 } from 'lucide-react';

export const BrewCalculator: React.FC = () => {
  const [dose, setDose] = useState<number>(15);
  const [ratio, setRatio] = useState<number>(16);
  const [method, setMethod] = useState<'v60' | 'origami' | 'kalita' | 'aeropress'>('v60');

  // Interactive Live Timer
  const [timerSeconds, setTimerSeconds] = useState(0);
  const [isTimerRunning, setIsTimerRunning] = useState(false);

  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (isTimerRunning) {
      interval = setInterval(() => {
        setTimerSeconds((prev) => prev + 1);
      }, 1000);
    } else if (!isTimerRunning && interval) {
      clearInterval(interval);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isTimerRunning]);

  const totalWater = Math.round(dose * ratio);
  const bloomWater = Math.round(dose * 3);
  const firstPourTarget = Math.round(totalWater * 0.6);
  const secondPourTarget = totalWater;

  const formatTimer = (totalSec: number) => {
    const mins = Math.floor(totalSec / 60);
    const secs = totalSec % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleResetTimer = () => {
    setIsTimerRunning(false);
    setTimerSeconds(0);
  };

  // Determine current active step based on timer
  const getCurrentStepIndex = () => {
    if (timerSeconds === 0) return 0;
    if (timerSeconds <= 45) return 1; // Bloom
    if (timerSeconds <= 90) return 2; // First pour
    if (timerSeconds <= 150) return 3; // Second pour
    return 4; // Drawdown finished
  };

  const activeStep = getCurrentStepIndex();

  return (
    <section id="brew-guide" className="py-16 sm:py-24 bg-[#F5EFEB] border-t border-[#E8E1D9]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="max-w-2xl mx-auto text-center mb-12 sm:mb-16">
          <div className="flex items-center justify-center gap-2 text-xs font-semibold text-[#8C6D53] tracking-widest uppercase mb-2">
            <span>Barista Ritual & Brewing Guide</span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl text-[#1C1917] font-bold tracking-tight">
            Kalkulator Seduh Mandiri NAMI
          </h2>
          <p className="mt-3 text-sm text-[#57534E] leading-relaxed">
            Hitung rasio seduhan presisi dan ikuti panduan penuangan langkah-demi-langkah 
            untuk mengeluarkan cita rasa optimal dari biji kopi single origin di rumah.
          </p>
        </div>

        {/* Main Grid: Left Controls & Output, Right Timer & Visual */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-stretch">
          
          {/* Left Panel: Recipe Controls (7 cols) */}
          <div className="lg:col-span-7 bg-white rounded-2xl border border-[#E0D7CB] p-6 sm:p-8 flex flex-col justify-between shadow-xs">
            <div className="space-y-6">
              
              {/* Method Selector */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#1C1917] mb-2.5">
                  1. Pilih Alat Seduh (Brew Method)
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {[
                    { id: 'v60', name: 'Hario V60', temp: '92°C' },
                    { id: 'origami', name: 'Origami Dripper', temp: '93°C' },
                    { id: 'kalita', name: 'Kalita Wave', temp: '91°C' },
                    { id: 'aeropress', name: 'AeroPress', temp: '88°C' },
                  ].map((m) => (
                    <button
                      key={m.id}
                      type="button"
                      onClick={() => setMethod(m.id as any)}
                      className={`p-3 rounded-xl border text-left transition-all ${
                        method === m.id
                          ? 'bg-[#1C1917] text-white border-[#1C1917] shadow-xs'
                          : 'bg-[#FAF8F5] text-[#57534E] border-[#DDD3C7] hover:bg-[#F2ECE4]'
                      }`}
                    >
                      <p className="text-xs font-bold leading-tight">{m.name}</p>
                      <p className={`text-[10px] mt-1 ${method === m.id ? 'text-amber-200' : 'text-[#78716C]'}`}>
                        Suhu {m.temp}
                      </p>
                    </button>
                  ))}
                </div>
              </div>

              {/* Coffee Dose Slider */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-xs font-bold uppercase tracking-wider text-[#1C1917]">
                    2. Takaran Kopi (Dose)
                  </label>
                  <span className="font-mono text-sm font-bold text-[#1C1917] bg-[#F2ECE4] px-2.5 py-1 rounded-md tabular-nums border border-[#DDD3C7]">
                    {dose} Gram
                  </span>
                </div>
                <input
                  type="range"
                  min="12"
                  max="30"
                  step="1"
                  value={dose}
                  onChange={(e) => setDose(Number(e.target.value))}
                  className="w-full accent-[#B45309] cursor-pointer"
                />
                <div className="flex justify-between text-[11px] text-[#78716C] font-mono mt-1">
                  <span>12g (1 Cangkir Mini)</span>
                  <span>15g (Standar Barista)</span>
                  <span>20g (Cangkir Besar)</span>
                  <span>30g (2 Porsi)</span>
                </div>
              </div>

              {/* Water Ratio Selector */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#1C1917] mb-2.5">
                  3. Karakter Rasa & Rasio Air
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { r: 15, title: 'Kuat & Tebal', ratioStr: '1:15' },
                    { r: 16, title: 'Seimbang (SCA)', ratioStr: '1:16' },
                    { r: 17, title: 'Ringan & Floral', ratioStr: '1:17' },
                  ].map((item) => (
                    <button
                      key={item.r}
                      type="button"
                      onClick={() => setRatio(item.r)}
                      className={`p-3 rounded-xl border text-center transition-all ${
                        ratio === item.r
                          ? 'bg-[#B45309] text-white border-[#B45309] shadow-xs'
                          : 'bg-[#FAF8F5] text-[#57534E] border-[#DDD3C7] hover:bg-[#F2ECE4]'
                      }`}
                    >
                      <p className="font-mono text-sm font-bold tabular-nums">{item.ratioStr}</p>
                      <p className={`text-[10px] mt-0.5 ${ratio === item.r ? 'text-amber-100' : 'text-[#78716C]'}`}>
                        {item.title}
                      </p>
                    </button>
                  ))}
                </div>
              </div>

              {/* Calculated Results Strip */}
              <div className="p-4 bg-[#FAF8F5] rounded-xl border border-[#E0D7CB] grid grid-cols-3 gap-3 text-center">
                <div>
                  <div className="flex items-center justify-center gap-1 text-[#78716C] text-[11px] mb-1">
                    <Droplets className="w-3.5 h-3.5 text-blue-500" />
                    <span>Total Air</span>
                  </div>
                  <p className="font-mono text-xl font-bold text-[#1C1917] tabular-nums">
                    {totalWater} ml
                  </p>
                </div>

                <div>
                  <div className="flex items-center justify-center gap-1 text-[#78716C] text-[11px] mb-1">
                    <Thermometer className="w-3.5 h-3.5 text-red-500" />
                    <span>Suhu Air</span>
                  </div>
                  <p className="font-mono text-xl font-bold text-[#1C1917] tabular-nums">
                    92° - 94°C
                  </p>
                </div>

                <div>
                  <div className="flex items-center justify-center gap-1 text-[#78716C] text-[11px] mb-1">
                    <Clock className="w-3.5 h-3.5 text-amber-600" />
                    <span>Waktu Seduh</span>
                  </div>
                  <p className="font-mono text-xl font-bold text-[#1C1917] tabular-nums">
                    2:30 - 3:00
                  </p>
                </div>
              </div>

            </div>
          </div>

          {/* Right Panel: Interactive Pour Timer & Visual Step Routine (5 cols) */}
          <div className="lg:col-span-5 bg-white rounded-2xl border border-[#E0D7CB] p-6 sm:p-7 flex flex-col justify-between shadow-xs">
            <div>
              {/* Photo Header */}
              <div className="relative rounded-xl overflow-hidden aspect-[16/9] mb-5 bg-[#EAE0D3]">
                <img
                  src="/src/assets/images/barista_pourover_1792994783105.jpg"
                  alt="Ritual penuangan manual brew barista Nami dengan ceret gooseneck"
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                <div className="absolute bottom-3 left-3 text-white">
                  <p className="text-[10px] font-mono tracking-widest uppercase opacity-80">RITUAL SEDUH</p>
                  <p className="text-sm font-serif font-bold">Pour-Over Technique Guide</p>
                </div>
              </div>

              {/* Digital Stopwatch UI */}
              <div className="text-center bg-[#FAF8F5] p-4 rounded-xl border border-[#E0D7CB] mb-5">
                <p className="text-[10px] font-bold text-[#78716C] uppercase tracking-wider mb-1">
                  Live Brew Timer
                </p>
                <div className="font-mono text-4xl font-bold tracking-tight text-[#1C1917] tabular-nums">
                  {formatTimer(timerSeconds)}
                </div>

                <div className="flex items-center justify-center gap-3 mt-3">
                  <button
                    onClick={() => setIsTimerRunning(!isTimerRunning)}
                    className={`inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold text-white transition-all ${
                      isTimerRunning
                        ? 'bg-amber-600 hover:bg-amber-700'
                        : 'bg-[#1C1917] hover:bg-[#2E2A27]'
                    }`}
                  >
                    {isTimerRunning ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                    <span>{isTimerRunning ? 'Jeda' : timerSeconds === 0 ? 'Mulai Seduh' : 'Lanjutkan'}</span>
                  </button>

                  <button
                    onClick={handleResetTimer}
                    className="p-2 rounded-lg text-[#57534E] hover:bg-[#F2ECE4] border border-[#DDD3C7] transition-colors"
                    aria-label="Reset Timer"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Step Sequence Guide */}
              <div className="space-y-2 text-xs">
                <div className={`p-2.5 rounded-lg border transition-all ${
                  activeStep === 1 ? 'bg-amber-50 border-amber-300 font-medium text-amber-950' : 'bg-[#FAF8F5] border-[#E8E1D9] text-[#57534E]'
                }`}>
                  <div className="flex items-center justify-between">
                    <span className="font-semibold">0:00 - 0:45 · Blooming</span>
                    <span className="font-mono font-bold tabular-nums">Tuang {bloomWater} ml</span>
                  </div>
                  <p className="text-[11px] text-[#78716C] mt-0.5">Basahi seluruh bubuk kopi secara merata untuk melepaskan gas CO2.</p>
                </div>

                <div className={`p-2.5 rounded-lg border transition-all ${
                  activeStep === 2 ? 'bg-amber-50 border-amber-300 font-medium text-amber-950' : 'bg-[#FAF8F5] border-[#E8E1D9] text-[#57534E]'
                }`}>
                  <div className="flex items-center justify-between">
                    <span className="font-semibold">0:45 - 1:30 · First Pour</span>
                    <span className="font-mono font-bold tabular-nums">Hingga {firstPourTarget} ml</span>
                  </div>
                  <p className="text-[11px] text-[#78716C] mt-0.5">Tuang gerakan spiral dari tengah ke luar dengan aliran tenang.</p>
                </div>

                <div className={`p-2.5 rounded-lg border transition-all ${
                  activeStep === 3 ? 'bg-amber-50 border-amber-300 font-medium text-amber-950' : 'bg-[#FAF8F5] border-[#E8E1D9] text-[#57534E]'
                }`}>
                  <div className="flex items-center justify-between">
                    <span className="font-semibold">1:30 - 2:15 · Final Pour</span>
                    <span className="font-mono font-bold tabular-nums">Hingga {secondPourTarget} ml</span>
                  </div>
                  <p className="text-[11px] text-[#78716C] mt-0.5">Pertahankan ketinggian air sampai tetes terakhir tuntas di 2:45.</p>
                </div>
              </div>
            </div>

            {timerSeconds >= 165 && (
              <div className="mt-4 p-3 bg-emerald-50 border border-emerald-200 rounded-lg flex items-center gap-2 text-xs text-emerald-800">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Seduhan tuntas sempurna! Goyangkan server dan nikmati selagi hangat.</span>
              </div>
            )}
          </div>

        </div>

      </div>
    </section>
  );
};
