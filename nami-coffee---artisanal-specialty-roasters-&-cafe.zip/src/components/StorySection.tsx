import React from 'react';
import { ArrowRight, Coffee, Award, Heart } from 'lucide-react';

export const StorySection: React.FC = () => {
  return (
    <section id="cerita" className="py-16 sm:py-24 border-t border-[#E8E1D9] bg-[#FAF8F5]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16 lg:space-y-24">
        
        {/* Narrative Block 1: The Wave Philosophy */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-center">
          
          <div className="lg:col-span-6 space-y-6">
            <div className="flex items-center gap-2 text-xs font-semibold text-[#8C6D53] tracking-widest uppercase">
              <span>Filosofi Kami</span>
              <span aria-hidden="true">·</span>
              <span>Zen & Specialty Craft</span>
            </div>

            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#1C1917] tracking-tight leading-tight" style={{ textWrap: 'balance' }}>
              Ombak Tenang di Tengah Keriuhan Kota.
            </h2>

            <p className="text-base text-[#57534E] leading-relaxed">
              Kata <strong className="text-[#1C1917]">NAMI (波)</strong> berasal dari bahasa Jepang yang bermakna 'ombak'. 
              Bagi kami, ombak melambangkan ritme kehidupan yang mengalir lembut namun bertenaga—sebuah jeda sadar 
              (mindful pause) yang mengembalikan fokus dan kejernihan pikiran Anda.
            </p>

            <p className="text-sm text-[#78716C] leading-relaxed">
              Didirikan oleh para kurator kopi dan pembuat roti artisan, NAMI hadir dengan satu komitmen jujur: 
              menghilangkan segala kepalsuan rasa industri dan menyajikan esensi murni dari tanah asal biji kopi 
              terbaik dunia langsung ke cangkir Anda.
            </p>

            <div className="grid grid-cols-2 gap-6 pt-4 border-t border-[#E8E1D9]">
              <div>
                <p className="font-serif text-2xl font-bold text-[#1C1917]">Loring S15</p>
                <p className="text-xs text-[#78716C] mt-1">Teknologi pemanggang udara panas nir-emisi untuk rasa biji yang jernih dan manis alami.</p>
              </div>
              <div>
                <p className="font-serif text-2xl font-bold text-[#1C1917]">Direct Trade</p>
                <p className="text-xs text-[#78716C] mt-1">Membayar 35% di atas standar fair-trade dunia kepada koperasi petani mitra lokal.</p>
              </div>
            </div>
          </div>

          <div className="lg:col-span-6 relative">
            <div className="relative rounded-2xl overflow-hidden aspect-[4/3] bg-[#EAE0D3] shadow-md border border-[#E0D7CB]">
              <img
                src="/src/assets/images/coffee_beans_origin_1792994783591.jpg"
                alt="Kemasan biji kopi kraft paper NAMI ORIGINS dan biji arabica tersangrai di atas baki kayu"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute bottom-4 left-4 right-4 bg-white/90 backdrop-blur-md p-3.5 rounded-xl border border-[#E0D7CB]">
                <p className="text-xs font-bold text-[#1C1917]">NAMI ORIGINS MICRO-LOT SELECTION</p>
                <p className="text-[11px] text-[#78716C]">Kurasi kopi bersertifikat Q-Grader internasional, disangrai setiap batch mingguan.</p>
              </div>
            </div>
          </div>

        </div>

        {/* Narrative Block 2: Artisanal Viennoiserie & Bakery */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-center">
          
          <div className="lg:col-span-6 order-2 lg:order-1 relative">
            <div className="relative rounded-2xl overflow-hidden aspect-[4/3] bg-[#EAE0D3] shadow-md border border-[#E0D7CB]">
              <img
                src="/src/assets/images/pastry_croissant_1792994783496.jpg"
                alt="Pastry almond croissant berlapis renyah dan cinnamon roll di atas piring keramik bintik artisanal"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute bottom-4 left-4 right-4 bg-white/90 backdrop-blur-md p-3.5 rounded-xl border border-[#E0D7CB]">
                <p className="text-xs font-bold text-[#1C1917]">SLOW FERMENTATION 48-HOURS</p>
                <p className="text-[11px] text-[#78716C]">Dipanggang segar setiap subuh pukul 05:00 menggunakan mentega murni Prancis AOP.</p>
              </div>
            </div>
          </div>

          <div className="lg:col-span-6 order-1 lg:order-2 space-y-6">
            <div className="flex items-center gap-2 text-xs font-semibold text-[#8C6D53] tracking-widest uppercase">
              <span>Atelier Pastry</span>
              <span aria-hidden="true">·</span>
              <span>Dipanggang Segar Setiap Hari</span>
            </div>

            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#1C1917] tracking-tight leading-tight" style={{ textWrap: 'balance' }}>
              Lapisan Pastry Renyah Berpadu Mentega Murni.
            </h2>

            <p className="text-base text-[#57534E] leading-relaxed">
              Secangkir kopi yang istimewa pantas didampingi oleh kudapan yang dibuat dengan standar yang sama tingginya. 
              Dapur bakery kami mempraktikkan seni laminasi adonan tradisional Prancis dengan waktu istirahat dingin 48 jam.
            </p>

            <p className="text-sm text-[#78716C] leading-relaxed">
              Hasilnya adalah tekstur sarang lebah (honeycomb) yang ringan, renyah di luar, lembut di dalam, 
              dengan aroma mentega susu murni yang menyatu sempurna bersama asam manis espresso single origin.
            </p>

            <ul className="space-y-3 pt-2">
              <li className="flex items-center gap-3 text-sm text-[#44403C]">
                <span className="w-1.5 h-1.5 rounded-full bg-[#B45309]" />
                <span>100% French Normandy Butter (tanpa margarin atau minyak nabati hidrogenasi)</span>
              </li>
              <li className="flex items-center gap-3 text-sm text-[#44403C]">
                <span className="w-1.5 h-1.5 rounded-full bg-[#B45309]" />
                <span>Ragi sourdough alami warisan 5 tahun untuk rasa gurih kompleks</span>
              </li>
              <li className="flex items-center gap-3 text-sm text-[#44403C]">
                <span className="w-1.5 h-1.5 rounded-full bg-[#B45309]" />
                <span>Batch terbatas dipanggang hangat 2 kali sehari (07:00 & 13:00)</span>
              </li>
            </ul>
          </div>

        </div>

      </div>
    </section>
  );
};
