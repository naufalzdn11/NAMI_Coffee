export interface Product {
  id: string;
  name: string;
  japaneseName: string;
  category: 'signature' | 'manual' | 'espresso' | 'bakery' | 'beans';
  price: number;
  description: string;
  notes: string[];
  image: string;
  badge?: string;
  origin?: string;
  roastLevel?: string;
  isPopular?: boolean;
}

export interface CartItem {
  cartItemId: string;
  product: Product;
  quantity: number;
  temperature?: 'Iced' | 'Hot';
  sweetness?: 'Normal (100%)' | 'Less Sugar (50%)' | 'No Sugar (0%)';
  milk?: 'Fresh Milk' | 'Oat Milk (+Rp 8.000)' | 'Almond Milk (+Rp 8.000)';
  grindSize?: 'Whole Bean (Biji Utuh)' | 'V60 / Pour Over' | 'AeroPress' | 'Espresso Machine' | 'Cold Brew Coarse';
  notes?: string;
  unitPrice: number;
}

export const PRODUCTS: Product[] = [
  {
    id: 'nami-cloud-latte',
    name: 'Nami Cloud Sea Salt Latte',
    japaneseName: '波 クラウドソルト',
    category: 'signature',
    price: 38000,
    description: 'Espresso single-origin dipadu dengan oat milk lembut, diberi topping krim vanila artisanal dan taburan sea salt Maldon yang gurih seimbang.',
    notes: ['Sea Salt Maldon', 'Caramelized Oat', 'Rich Crema'],
    image: '/src/assets/images/coffee_signature_latte_1792994781966.jpg',
    badge: 'Signature House',
    isPopular: true
  },
  {
    id: 'ethiopia-yirgacheffe-v60',
    name: 'Ethiopia Yirgacheffe G1 Washed',
    japaneseName: 'エチオピア イルガチェフェ',
    category: 'manual',
    price: 42000,
    description: 'Diseduh perlahan dengan teknik V60 Origami. Menghadirkan karakter aromatik melati yang anggun, buah peach manis, dan akhiran teh bergamot yang bersih.',
    notes: ['Jasmine Floral', 'White Peach', 'Bergamot Tea'],
    image: '/src/assets/images/barista_pourover_1792994783105.jpg',
    origin: 'Yirgacheffe, Southern Ethiopia (2.050 mdpl)',
    roastLevel: 'Light Roast',
    badge: 'Barista Choice',
    isPopular: true
  },
  {
    id: 'beans-nami-origins-colombia',
    name: 'NAMI Origins: Colombia Huila Washed (250g)',
    japaneseName: 'ナミ オリジンズ コロンビア',
    category: 'beans',
    price: 135000,
    description: 'Biji kopi sangrai segar kurasi micro-lot Huila. Body velvety dengan perpaduan rasa apel merah matang, stone fruit lembut, dan sirup karamel pekat.',
    notes: ['Red Apple', 'Stone Fruit', 'Dark Toffee'],
    image: '/src/assets/images/coffee_beans_origin_1792994783591.jpg',
    origin: 'Huila, Colombia · Fully Washed',
    roastLevel: 'Medium Light Roast',
    badge: 'Freshly Roasted'
  },
  {
    id: 'almond-twice-baked-croissant',
    name: 'Twice-Baked Almond Brioche Croissant',
    japaneseName: 'アーモンド クロワッサン',
    category: 'bakery',
    price: 36000,
    description: 'Croissant mentega Prancis fermentasi 48 jam, dipanggang dua kali dengan isian frangipane almond harum dan taburan kacang almond renyah.',
    notes: ['French Butter 84%', 'Pure Almond Cream', 'Flaky Crisp'],
    image: '/src/assets/images/pastry_croissant_1792994783496.jpg',
    badge: 'Fresh Daily 07:00',
    isPopular: true
  },
  {
    id: 'kyoto-cold-brew-18h',
    name: 'Kyoto Drip 18-Hour Cold Extraction',
    japaneseName: '京都 スロードリップ',
    category: 'signature',
    price: 40000,
    description: 'Ekstraksi tetes lambat selama 18 jam menggunakan menara kaca tradisional Kyoto. Karakter minuman sangat jernih, minim asam getir, dengan nuansa cokelat hitam dan anggur fermentasi.',
    notes: ['Dark Cocoa', 'Rum Raisin', 'Velvety Body'],
    image: '/src/assets/images/hero_nami_coffee_1792994781675.jpg',
    badge: 'Limited Batch'
  },
  {
    id: 'tokyo-flat-white',
    name: 'Tokyo Classic Flat White',
    japaneseName: '東京 フラットホワイト',
    category: 'espresso',
    price: 35000,
    description: 'Double ristretto dari house blend Nami dipadukan dengan microfoam susu creamy bersuhu tepat 62°C untuk mempertahankan kemanisan alami.',
    notes: ['Hazelnut Praline', 'Creamy Milk', 'Bittersweet Cocoa'],
    image: '/src/assets/images/coffee_signature_latte_1792994781966.jpg',
    isPopular: true
  },
  {
    id: 'cinnamon-cardamom-swirl',
    name: 'Nordic Cardamom & Cinnamon Swirl',
    japaneseName: 'カルダモン ロール',
    category: 'bakery',
    price: 32000,
    description: 'Roti gulung gaya Skandinavia dengan aroma kapulaga organik dan kayu manis Ceylon yang dipanggang dengan mentega karamel manis harum.',
    notes: ['Ceylon Cinnamon', 'Organic Green Cardamom', 'Pearl Sugar'],
    image: '/src/assets/images/pastry_croissant_1792994783496.jpg'
  },
  {
    id: 'beans-bali-kintamani-anaerobic',
    name: 'Bali Kintamani Natural Anaerobic (250g)',
    japaneseName: 'バリ キンタマーニ アナエロビック',
    category: 'beans',
    price: 120000,
    description: 'Proses fermentasi anaerobik 72 jam menghasilkan karakter buah tropis eksotis: jeruk kintamani manis, markisa, dan brown sugar lembut.',
    notes: ['Kintamani Orange', 'Passionfruit', 'Molasses'],
    image: '/src/assets/images/coffee_beans_origin_1792994783591.jpg',
    origin: 'Kintamani, Bali (1.300 mdpl)',
    roastLevel: 'Filter Light Roast'
  },
  {
    id: 'hojicha-dirty-latte',
    name: 'Kyoto Hojicha Dirty Espresso',
    japaneseName: 'ほうじ茶 ダーティラテ',
    category: 'signature',
    price: 38000,
    description: 'Lapisan susu dingin dengan seduhan teh hijau panggang (hojicha) Uji Kyoto yang pekat, ditutup dengan single ristretto hangat yang mengambang.',
    notes: ['Smoky Roasted Tea', 'Earthiness', 'Sweet Espresso'],
    image: '/src/assets/images/coffee_signature_latte_1792994781966.jpg'
  }
];

export interface LocationInfo {
  id: string;
  name: string;
  address: string;
  city: string;
  hours: string;
  phone: string;
  googleMapsUrl: string;
  amenities: string[];
}

export const LOCATIONS: LocationInfo[] = [
  {
    id: 'senopati',
    name: 'NAMI Coffee Sanctuary — Senopati',
    address: 'Jl. Senopati No. 42, Kebayoran Baru',
    city: 'Jakarta Selatan 12190',
    hours: 'Setiap Hari · 07:00 - 22:00 WIB',
    phone: '+62 81384488853',
    googleMapsUrl: 'https://maps.google.com/?q=Senopati+Jrta',
    amenities: ['Indoor AC & Zen Garden', 'High-Speed Wi-Fi (150 Mbps)', 'Banyak Power Socket', 'Musholla', 'Pet Friendly Outdoor']
  },
  
];

export const REVIEWS = [
  {
    id: 'rev-1',
    author: 'Reza Pramudya',
    role: 'Q-Grader & Coffee Enthusiast',
    rating: 5,
    date: '24 Oktober 2026',
    comment: 'Penyajian V60 Ethiopia Yirgacheffe-nya luar biasa jernih. Catatan floral melati dan aciditas peach-nya keluar sangat teratur tanpa over-extraction. Suasana kafe bernuansa kayu Jepang sangat menenangkan untuk fokus kerja.',
    favorite: 'Ethiopia Yirgacheffe V60'
  },
  {
    id: 'rev-2',
    author: 'Astrid Wibisono',
    role: 'Architect & Regular Guest',
    rating: 5,
    date: '19 Oktober 2026',
    comment: 'Nami Cloud Sea Salt Latte adalah racikan iced coffee terbaik di Jakarta. Foam vanila-nya tidak terlalu manis dan sentuhan kristal garam Maldon membuat rasanya sangat mewah. Pastry croissant-nya buttery dan berlapis renyah!',
    favorite: 'Nami Cloud Sea Salt Latte'
  },
  {
    id: 'rev-3',
    author: 'Dimas Wicaksono',
    role: 'Creative Director',
    rating: 5,
    date: '12 Oktober 2026',
    comment: 'Interior minimalis dengan pencahayaan alami yang hangat. Barista ramah dan berpengetahuan luas tentang profil seduh. Sangat merekomendasikan untuk siapa pun yang menghargai cita rasa kopi murni.',
    favorite: 'Kyoto Cold Brew 18h'
  }
];
